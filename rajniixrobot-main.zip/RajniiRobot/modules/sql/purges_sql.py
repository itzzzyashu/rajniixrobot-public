"""
BSD 2-Clause License

Copyright (C) 2017-2019, Paul Larsen
Copyright (C) 2021-2022, Awesome-RJ, [ https://github.com/Awesome-RJ ]
Copyright (c) 2021-2022, Yūki • Black Knights Union, [ https://github.com/Awesome-RJ/CutiepiiRobot ]

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
"""
#Purges_SQL for /purgefrom & /purgeto

import threading

from RajniiRobot.modules.sql import BASE, SESSION
from sqlalchemy import (Column, Integer, String)


class Purges(BASE):
    __tablename__ = "purges"
    chat_id = Column(String(14), primary_key=True)
    message_from = Column(Integer, primary_key=True)


    def __init__(self, chat_id, message_from):
        self.chat_id = str(chat_id)  # ensure string
        self.message_from = message_from


    def __repr__(self):
        return f"<Purges {self.chat_id}>"


Purges.__table__.create(checkfirst=True)

PURGES_INSERTION_LOCK = threading.RLock()

def purgefrom(chat_id, message_from):
    with PURGES_INSERTION_LOCK:
        note = Purges(str(chat_id), message_from)
        SESSION.add(note)
        SESSION.commit()

def is_purgefrom(chat_id, message_from):
    try:
        return SESSION.query(Purges).get((str(chat_id), message_from))
    finally:
        SESSION.close()

def clear_purgefrom(chat_id, message_from):
    with PURGES_INSERTION_LOCK:
        if note := SESSION.query(Purges).get((str(chat_id), message_from)):
            SESSION.delete(note)
            SESSION.commit()
            return True
        SESSION.close()
        return False

def show_purgefrom(chat_id):
    try:
        return SESSION.query(Purges).filter(Purges.chat_id == str(chat_id)).order_by(Purges.message_from.asc()).all()
    finally:
        SESSION.close()